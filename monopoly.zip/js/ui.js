/** UI — επιλογή παικτών, ταμπλό, ενέργειες. */

let game = null;
const PLAYER_COLORS = ["#c0392b", "#2471a3", "#1e8449", "#8e44ad", "#d68910", "#2c3e50"];

const boardEl = () => document.getElementById("board");

/** Θέση 0 = κάτω δεξιά (Αφετηρία), αριστερόστροφα… δεξιόστροφα κίνηση πάνω στο ταμπλό. */
function gridPos(index) {
  // Κάτω σειρά: 0..10 από δεξιά προς αριστερά → col 11..1, row 11
  if (index <= 10) return { col: 11 - index, row: 11 };
  // Αριστερή στήλη: 11..20 από κάτω προς πάνω → col 1, row 10..1
  if (index <= 20) return { col: 1, row: 11 - (index - 10) };
  // Πάνω σειρά: 21..30 από αριστερά προς δεξιά → col 2..11, row 1
  if (index <= 30) return { col: index - 20 + 1, row: 1 };
  // Δεξιά στήλη: 31..39 από πάνω προς κάτω → col 11, row 2..10
  return { col: 11, row: index - 30 + 1 };
}

function tokenMeta(id) {
  return TOKENS.find((t) => t.id === id) || TOKENS[0];
}

/* ---------- Setup ---------- */
function initSetup() {
  const list = document.getElementById("player-setup-list");
  list.innerHTML = "";
  addPlayerRow("Παίκτης 1");
  addPlayerRow("Παίκτης 2");

  document.getElementById("btn-add-player").onclick = () => {
    const n = list.children.length + 1;
    if (n > 6) return;
    addPlayerRow(`Παίκτης ${n}`);
    document.getElementById("btn-add-player").disabled = n >= 6;
  };

  document.getElementById("btn-start").onclick = startGame;
}

function addPlayerRow(defaultName) {
  const list = document.getElementById("player-setup-list");
  const used = [...list.querySelectorAll("select")].map((s) => s.value);
  const free = TOKENS.find((t) => !used.includes(t.id)) || TOKENS[0];
  const row = document.createElement("div");
  row.className = "player-row";
  const n = list.children.length + 1;
  row.innerHTML = `
    <input type="text" class="pname" name="player-name-${n}" maxlength="20" value="${defaultName}" autocomplete="off" />
    <select class="ptoken" name="player-token-${n}">
      ${TOKENS.map((t) => `<option value="${t.id}" ${t.id === free.id ? "selected" : ""}>${t.emoji} ${t.label}</option>`).join("")}
    </select>
    <button type="button" class="btn small danger btn-remove" title="Αφαίρεση">✕</button>
  `;
  row.querySelector(".btn-remove").onclick = () => {
    if (list.children.length <= 2) return;
    row.remove();
    document.getElementById("btn-add-player").disabled = false;
  };
  list.appendChild(row);
}

function startGame() {
  const err = document.getElementById("setup-error");
  err.hidden = true;
  const rows = [...document.querySelectorAll("#player-setup-list .player-row")];
  const defs = [];
  const tokens = new Set();
  document.getElementById("header").style.visibility = "hidden";
  for (const row of rows) {
    const name = row.querySelector(".pname").value.trim() || "Παίκτης";
    const token = row.querySelector(".ptoken").value;
    if (tokens.has(token)) {
      err.textContent = "Κάθε παίκτης πρέπει να έχει διαφορετικό πιόνι.";
      err.hidden = false;
      return;
    }
    tokens.add(token);
    defs.push({ name, token });
  }
  if (defs.length < 2) {
    err.textContent = "Χρειάζονται τουλάχιστον 2 παίκτες.";
    err.hidden = false;
    return;
  }
  game = new MonopolyGame(defs);
  game.onRoll = () => {
    renderDice();
    renderActions();
  };
  game.onStep = async () => {
    updateBoardPieces();
    renderPlayers();
    renderDice();
    renderLog();
    renderActions();
    await new Promise((resolve) => setTimeout(resolve, 300));
  };
  game.onCard = (card) => new Promise((resolve) => {
    const finish = () => {
      if (game._resumeCard !== finish) return;
      game._resumeCard = null;
      game.lastCard = null;
      hideModal();
      resolve();
    };
    game._resumeCard = finish;
    game.lastCard = null;
    showModal(card.label, `<div class="card-reveal">${escapeHtml(card.text)}</div>`, [
      { label: "OK", primary: true, onClick: finish },
    ]);
    renderLog();
    renderPlayers();
  });
  document.getElementById("setup").hidden = true;
  document.getElementById("game").hidden = false;
  buildBoard();
  render();
}

/* ---------- Board ---------- */
const ICONS = {
  chance: `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="26" fill="#fff" stroke="#e10600" stroke-width="4"/><text x="32" y="44" text-anchor="middle" font-size="38" font-weight="800" fill="#e10600" font-family="Georgia,serif">?</text></svg>`,
  chest: `<svg viewBox="0 0 64 52" aria-hidden="true"><path d="M6 22h52v24H6z" fill="#c0392b" stroke="#1a1a1a" stroke-width="2"/><path d="M6 22c0-12 52-12 52 0" fill="#e74c3c" stroke="#1a1a1a" stroke-width="2"/><rect x="28" y="26" width="8" height="10" rx="1" fill="#f1c40f" stroke="#1a1a1a"/></svg>`,
  train: `<svg viewBox="0 0 70 40" aria-hidden="true"><rect x="6" y="12" width="40" height="16" rx="2" fill="#222"/><rect x="42" y="16" width="16" height="12" fill="#333"/><rect x="10" y="15" width="12" height="7" fill="#9fd4f5"/><circle cx="18" cy="32" r="4" fill="#666" stroke="#111" stroke-width="1.5"/><circle cx="36" cy="32" r="4" fill="#666" stroke="#111" stroke-width="1.5"/><circle cx="52" cy="32" r="4" fill="#666" stroke="#111" stroke-width="1.5"/></svg>`,
  bulb: `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="26" r="14" fill="#ffe14a" stroke="#1a1a1a" stroke-width="2"/><rect x="25" y="38" width="14" height="8" fill="#eee" stroke="#1a1a1a" stroke-width="2"/><path d="M27 48h10M28 52h8" stroke="#1a1a1a" stroke-width="2"/></svg>`,
  tap: `<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M8 18h34v10H30v8a8 8 0 0 1-16 0v-6H8z" fill="#5dade2" stroke="#1a1a1a" stroke-width="2"/><path d="M22 44v10" stroke="#5dade2" stroke-width="3" stroke-linecap="round"/></svg>`,
  car: `<svg viewBox="0 0 70 40" aria-hidden="true"><path d="M8 24h8l6-10h22l8 10h8v8H8z" fill="#e10600" stroke="#1a1a1a" stroke-width="2"/><circle cx="22" cy="32" r="5" fill="#222"/><circle cx="50" cy="32" r="5" fill="#222"/></svg>`,
  jail: `<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="6" width="48" height="52" rx="2" fill="#f4efe4" stroke="#1a1a1a" stroke-width="2"/><path d="M18 8v48M28 8v48M38 8v48M48 8v48" stroke="#1a1a1a" stroke-width="3"/><circle cx="32" cy="30" r="6" fill="#f5cba7" stroke="#1a1a1a"/></svg>`,
  cop: `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="34" cy="16" r="7" fill="#f5cba7" stroke="#1a1a1a" stroke-width="2"/><path d="M24 14h20l-2 6H26z" fill="#1a3a6b" stroke="#1a1a1a"/><path d="M24 28h20l4 22H20z" fill="#1a3a6b" stroke="#1a1a1a" stroke-width="2"/><path d="M20 36H8l6 6" stroke="#1a1a1a" stroke-width="3" fill="none"/><circle cx="46" cy="18" r="3" fill="#f1c40f" stroke="#1a1a1a"/></svg>`,
  arrow: `<svg viewBox="0 0 80 36" aria-hidden="true"><polygon points="4,18 28,2 28,10 76,10 76,26 28,26 28,34" fill="#e10600"/></svg>`,
  tax: `<svg viewBox="0 0 64 64" aria-hidden="true"><polygon points="32,4 58,32 32,60 6,32" fill="#f4d03f" stroke="#1a1a1a" stroke-width="2"/></svg>`,
};

function edgeOf(index) {
  if (index <= 10) return "bottom";
  if (index <= 20) return "left";
  if (index <= 30) return "top";
  return "right";
}

function nameParts(name) {
  const prefixes = ["Λεωφόρος ", "Πλατεία ", "Σιδηρόδρομος ", "Σταθμός ", "Οδός ", "Εταιρία "];
  for (const prefix of prefixes) {
    if (name.startsWith(prefix)) {
      return { kicker: prefix.trim(), title: name.slice(prefix.length) };
    }
  }
  return { kicker: "", title: name };
}

function buildBoard() {
  const board = boardEl();
  board.innerHTML = "";
  const center = document.createElement("div");
  center.className = "board-center";
  center.innerHTML = `
    <div class="deck deck-chest"><span>ΕΝΤΟΛΗ</span></div>
    <div class="logo-word">MONOPOLY</div>
    <div class="deck deck-chance"><span>ΑΠΟΦΑΣΗ</span></div>
  `;
  board.appendChild(center);

  for (let i = 0; i < 40; i++) {
    const space = BOARD[i];
    const { col, row } = gridPos(i);
    const cell = document.createElement("div");
    const edge = edgeOf(i);
    const corner = space.type === "go" || space.type === "jail" || space.type === "parking" || space.type === "gotojail";
    cell.className = `cell edge-${edge} type-${space.type}${corner ? " corner" : ""}`;
    cell.dataset.index = String(i);
    cell.style.gridColumn = String(col);
    cell.style.gridRow = String(row);
    cell.title = space.name;
    cell.innerHTML = squareHtml(space) + `<div class="buildings" data-buildings></div><div class="tokens" data-tokens></div>`;
    board.appendChild(cell);
  }
}

function squareHtml(space) {
  if (space.type === "go") {
    return `<div class="corner-art go-art">
      <div class="go-collect">ΠΕΡΝΩΝΤΑΣ ΠΑΙΡΝΕΙΣ<br>20.000</div>
      <div class="go-title">ΑΦΕΤΗΡΙΑ</div>
      <div class="go-arrow">${ICONS.arrow}</div>
    </div>`;
  }
  if (space.type === "jail") {
    return `<div class="corner-art jail-art">
      <div class="jail-window">${ICONS.jail}</div>
      <div class="jail-caption"><b>ΦΥΛΑΚΗ</b><span>μόνο επίσκεψη</span></div>
    </div>`;
  }
  if (space.type === "parking") {
    return `<div class="corner-art park-art">
      <div class="corner-icon">${ICONS.car}</div>
      <div class="corner-label">ΔΩΡΕΑΝ<br>ΣΤΑΘΜΕΥΣΗ</div>
    </div>`;
  }
  if (space.type === "gotojail") {
    return `<div class="corner-art goto-art">
      <div class="corner-icon">${ICONS.cop}</div>
      <div class="corner-label">ΠΗΓΑΙΝΕ<br>ΣΤΗ ΦΥΛΑΚΗ</div>
    </div>`;
  }

  const parts = nameParts(space.name);
  const long = parts.title.length > 11 ? " long" : "";
  const kicker = parts.kicker ? `<span class="kicker">${escapeHtml(parts.kicker)}</span>` : "";
  const title = `<span class="title${long}">${escapeHtml(parts.title)}</span>`;
  let head = "";
  let price = "";

  if (space.type === "property") {
    head = `<div class="color-bar" style="background:${COLOR_HEX[space.color]}"></div>`;
    price = `<div class="price">${Number(space.price).toLocaleString("el-GR")}</div>`;
  } else if (space.type === "station") {
    head = `<div class="icon">${ICONS.train}</div>`;
    price = `<div class="price">${Number(space.price).toLocaleString("el-GR")}</div>`;
  } else if (space.type === "utility") {
    head = `<div class="icon">${space.name.includes("ΕΥΔΑΠ") ? ICONS.tap : ICONS.bulb}</div>`;
    price = `<div class="price">${Number(space.price).toLocaleString("el-GR")}</div>`;
  } else if (space.type === "chance") {
    head = `<div class="icon big">${ICONS.chance}</div>`;
  } else if (space.type === "chest") {
    head = `<div class="icon big">${ICONS.chest}</div>`;
  } else if (space.type === "tax") {
    head = `<div class="icon">${ICONS.tax}</div>`;
    price = `<div class="price">${Number(space.amount).toLocaleString("el-GR")}</div>`;
  }

  return `<div class="sq-rot">${head}<div class="name">${kicker}${title}</div>${price}</div>`;
}

function updateBoardPieces() {
  if (!game) return;
  document.querySelectorAll(".cell").forEach((cell) => {
    const idx = Number(cell.dataset.index);
    const tokBox = cell.querySelector("[data-tokens]");
    const bldBox = cell.querySelector("[data-buildings]");
    tokBox.innerHTML = "";
    bldBox.innerHTML = "";
    cell.classList.remove("owned");
    cell.style.removeProperty("--owner");

    const own = game.ownership[idx];
    cell.classList.toggle("mortgaged", !!(own && own.mortgaged));
    if (own) {
      cell.classList.add("owned");
      cell.style.setProperty("--owner", PLAYER_COLORS[own.ownerId % PLAYER_COLORS.length]);
      if (own.houses === 5) {
        bldBox.innerHTML = `<span class="hotel-dot" title="Ξενοδοχείο"></span>`;
      } else {
        bldBox.innerHTML = Array.from({ length: own.houses }, () => `<span class="house-dot"></span>`).join("");
      }
    }

    game.players.forEach((p) => {
      if (p.bankrupt || p.position !== idx) return;
      // Στη φυλακή vs επίσκεψη: ίδιο τετράγωνο
      const pip = document.createElement("span");
      pip.className = "token-pip" + (p.id === game.current ? " current" : "");
      pip.title = p.name + (p.inJail ? " (φυλακή)" : "");
      pip.textContent = tokenMeta(p.token).emoji;
      pip.style.borderColor = PLAYER_COLORS[p.id % PLAYER_COLORS.length];
      tokBox.appendChild(pip);
    });
  });
}

/* ---------- Render ---------- */
function render() {
  if (!game) return;
  updateBoardPieces();
  renderPlayers();
  renderTurn();
  renderDice();
  renderActions();
  renderManage();
  renderTrade();
  renderLog();
}

function renderPlayers() {
  const panel = document.getElementById("players-panel");
  panel.innerHTML = game.players.map((p) => {
    const props = game.propertiesOf(p.id);
    const tok = tokenMeta(p.token);
    return `
      <div class="player-card ${p.id === game.current && !p.bankrupt ? "active" : ""} ${p.bankrupt ? "bankrupt" : ""}">
        <div class="player-head">
          <span>${tok.emoji} ${escapeHtml(p.name)}</span>
          <span class="money">${p.bankrupt ? "Χρεοκοπία" : formatMoney(p.money)}</span>
        </div>
        <div style="font-size:0.8rem;color:#666;margin:4px 0;">
          ${BOARD[p.position].name}${p.inJail ? " · Φυλακή" : ""}
          ${p.jailFreeCards ? ` · 🆓×${p.jailFreeCards}` : ""}
        </div>
        <div>
          ${props.map((pr) => {
            const bg = pr.space.color ? COLOR_HEX[pr.space.color] : (pr.space.type === "station" ? "#333" : "#5dade2");
            const houses = pr.houses === 5 ? " 🏨" : pr.houses ? ` 🏠×${pr.houses}` : "";
            return `<span class="prop-chip ${pr.mortgaged ? "mortgaged" : ""}" style="background:${bg}" title="${pr.space.name}">${pr.space.name.replace(/^(Οδός |Πλατεία |Λεωφόρος |Σταθμός )/, "")}${houses}</span>`;
          }).join("")}
        </div>
      </div>
    `;
  }).join("");
}

function renderTurn() {
  const p = game.currentPlayer;
  const el = document.getElementById("turn-banner");
  if (game.winner) {
    el.textContent = `🏆 Νικητής: ${game.winner.name}`;
    return;
  }
  el.textContent = `Σειρά: ${tokenMeta(p.token).emoji} ${p.name}`;
}

function renderDice() {
  const [d1, d2] = game.dice;
  const box = document.getElementById("dice-display");
  box.innerHTML = `<span class="die">${d1 || "?"}</span><span class="die">${d2 || "?"}</span>`;
  const btn = document.getElementById("btn-roll");
  btn.disabled = game.phase !== "roll" || !!game.winner || game.animating;
}

function renderActions() {
  const area = document.getElementById("action-area");
  const p = game.currentPlayer;

  if (game.winner) {
    area.innerHTML = `<p><strong>Το παιχνίδι τελείωσε.</strong> Νικητής: ${escapeHtml(game.winner.name)}!</p>
      <button class="btn primary" id="btn-restart">Νέο παιχνίδι</button>`;
    area.querySelector("#btn-restart").onclick = () => location.reload();
    return;
  }

  if (game.animating) {
    area.innerHTML = `<p>Το πιόνι κινείται…</p>`;
    return;
  }

  if (game.phase === "roll" && p.inJail) {
    area.innerHTML = `
      <p><strong>${escapeHtml(p.name)}</strong>, είσαι στη Φυλακή. Ρίξε διπλές ή πλήρωσε ${formatMoney(JAIL_FINE)}.</p>
      <div class="action-buttons">
        <button class="btn secondary" id="btn-pay-jail">Πληρωμή ${formatMoney(JAIL_FINE)}</button>
        ${p.jailFreeCards ? `<button class="btn success" id="btn-jail-card">Κάρτα εξόδου</button>` : ""}
      </div>`;
    area.querySelector("#btn-pay-jail").onclick = () => {
      if (game.payJailFine()) render();
      else flash("Δεν μπορείς να πληρώσεις ακόμα — υποθήκευσε ιδιοκτησίες.");
    };
    const jc = area.querySelector("#btn-jail-card");
    if (jc) jc.onclick = () => { game.useJailFreeCard(); render(); };
    return;
  }

  if (game.phase === "buy" && game.pendingBuy != null) {
    const space = BOARD[game.pendingBuy];
    area.innerHTML = `
      <p><strong>${escapeHtml(p.name)}</strong>, έπεσες στο/στην <strong>${escapeHtml(space.name)}</strong> (${formatMoney(space.price)}).</p>
      <div class="action-buttons">
        <button class="btn success" id="btn-buy" ${p.money < space.price ? "disabled" : ""}>Αγορά</button>
        <button class="btn secondary" id="btn-auction">Δημοπρασία</button>
      </div>`;
    area.querySelector("#btn-buy").onclick = () => { game.buyProperty(); maybeShowCard(); render(); };
    area.querySelector("#btn-auction").onclick = () => { game.declineBuy(); render(); };
    return;
  }

  if (game.phase === "auction" && game.auction) {
    const a = game.auction;
    const bidder = game.players[a.bidders[a.turn]];
    const space = BOARD[a.idx];
    area.innerHTML = `
      <p>🔨 Δημοπρασία: <strong>${escapeHtml(space.name)}</strong><br>
      Τρέχουσα προσφορά: <strong>${formatMoney(a.currentBid)}</strong>
      ${a.highBidder != null ? `(${escapeHtml(game.players[a.highBidder].name)})` : ""}<br>
      Σειρά πλειοδοσίας: <strong>${escapeHtml(bidder.name)}</strong> (${formatMoney(bidder.money)})</p>
      <div class="action-buttons">
        <input type="number" id="bid-amount" min="${a.currentBid + 100}" step="100" value="${a.currentBid + 1000}" style="width:120px" />
        <button class="btn success" id="btn-bid">Προσφορά</button>
        <button class="btn danger" id="btn-pass">Πάσο</button>
      </div>`;
    area.querySelector("#btn-bid").onclick = () => {
      const v = area.querySelector("#bid-amount").value;
      if (!game.auctionBid(v)) flash("Μη έγκυρη προσφορά.");
      render();
    };
    area.querySelector("#btn-pass").onclick = () => { game.auctionPass(); render(); };
    return;
  }

  if (game.phase === "must-pay" && game.pendingRent) {
    const d = game.pendingRent;
    area.innerHTML = `
      <p>⚠️ <strong>${escapeHtml(p.name)}</strong> οφείλει <strong>${formatMoney(d.amount)}</strong> (${escapeHtml(d.reason)}).<br>
      Έχεις ${formatMoney(p.money)}. Υποθήκευσε ή πούλησε κτίρια και πάτα «Πληρωμή».</p>
      <div class="action-buttons">
        <button class="btn primary" id="btn-settle">Πληρωμή</button>
      </div>`;
    area.querySelector("#btn-settle").onclick = () => {
      if (!game.trySettleDebt()) flash("Ακόμα δεν φτάνουν τα χρήματα.");
      render();
    };
    return;
  }

  if (game.phase === "end" || (game.phase === "roll" && game.lastDoubles === false && game.dice[0])) {
    // μετά από κίνηση χωρίς διπλές
  }

  if (game.phase === "end") {
    area.innerHTML = `
      <p>Τέλος γύρου για <strong>${escapeHtml(p.name)}</strong>.</p>
      <button class="btn primary wide" id="btn-end">Επόμενος παίκτης</button>`;
    area.querySelector("#btn-end").onclick = () => { game.endTurn(); render(); };
    return;
  }

  if (game.phase === "roll") {
    area.innerHTML = `<p>Ρίξε τα ζάρια όταν είσαι έτοιμος/η, <strong>${escapeHtml(p.name)}</strong>.</p>
      ${game.lastDoubles && game.dice[0] ? "<p>Έφερες διπλές — ξαναρίχνεις!</p>" : ""}`;
    return;
  }

  area.innerHTML = `<p>Φάση: ${game.phase}</p>`;
}

function maybeShowCard() {
  if (game.lastCard) {
    showModal(game.lastCard.label, `<div class="card-reveal">${escapeHtml(game.lastCard.text)}</div>`, [
      { label: "OK", primary: true, onClick: hideModal },
    ]);
    game.lastCard = null;
  }
}

function renderManage() {
  const area = document.getElementById("manage-area");
  if (!game || game.winner) {
    area.innerHTML = "";
    return;
  }
  const p = game.currentPlayer;
  const props = game.propertiesOf(p.id);
  if (!props.length) {
    area.innerHTML = `<p style="color:#888;font-size:0.85rem;">Δεν έχεις ιδιοκτησίες ακόμα.</p>`;
    return;
  }
  area.innerHTML = props.map((pr) => {
    const isProp = pr.space.type === "property";
    const buildOk = isProp && game.canBuildHouse(pr.idx);
    const sellOk = isProp && game.canSellHouse(pr.idx);
    return `
      <div class="manage-item" data-idx="${pr.idx}">
        <div class="label">${escapeHtml(pr.space.name)}
          ${pr.mortgaged ? " (υποθήκη)" : ""}
          ${pr.houses === 5 ? " · ξενοδοχείο" : pr.houses ? ` · ${pr.houses} σπίτια` : ""}
        </div>
        ${isProp ? `<button class="btn small success btn-build" ${buildOk ? "" : "disabled"}>+ Κτίριο</button>
        <button class="btn small danger btn-sellh" ${sellOk ? "" : "disabled"}>− Κτίριο</button>` : ""}
        ${!pr.mortgaged && pr.houses === 0 ? `<button class="btn small btn-mort">Υποθήκη</button>` : ""}
        ${pr.mortgaged ? `<button class="btn small secondary btn-unmort">Εξόφληση</button>` : ""}
      </div>`;
  }).join("");

  area.querySelectorAll(".manage-item").forEach((el) => {
    const idx = Number(el.dataset.idx);
    el.querySelector(".btn-build")?.addEventListener("click", () => {
      const r = game.buildHouse(idx);
      if (!r.ok) flash(r.err);
      render();
    });
    el.querySelector(".btn-sellh")?.addEventListener("click", () => {
      const r = game.sellHouse(idx);
      if (!r.ok) flash(r.err);
      render();
    });
    el.querySelector(".btn-mort")?.addEventListener("click", () => {
      const r = game.mortgage(idx);
      if (!r.ok) flash(r.err);
      render();
    });
    el.querySelector(".btn-unmort")?.addEventListener("click", () => {
      const r = game.unmortgage(idx);
      if (!r.ok) flash(r.err);
      render();
    });
  });
}

function renderTrade() {
  const area = document.getElementById("trade-area");
  if (!game || game.winner) {
    area.innerHTML = "";
    return;
  }
  const me = game.currentPlayer;
  const others = game.alivePlayers().filter((p) => p.id !== me.id);
  if (!others.length) {
    area.innerHTML = "";
    return;
  }
  const myProps = game.propertiesOf(me.id).filter((p) => p.houses === 0);
  area.innerHTML = `
    <label>Με παίκτη
      <select id="trade-with">${others.map((o) => `<option value="${o.id}">${escapeHtml(o.name)}</option>`).join("")}</select>
    </label>
    <label style="display:block;margin-top:6px;">Δίνεις χρήματα
      <input type="number" id="trade-money-from" min="0" step="100" value="0" />
    </label>
    <label style="display:block;margin-top:6px;">Παίρνεις χρήματα
      <input type="number" id="trade-money-to" min="0" step="100" value="0" />
    </label>
    <div style="margin-top:8px;font-size:0.8rem;">Οι ιδιοκτησίες σου (επίλεξε όσες δίνεις):</div>
    <div id="trade-props-from">
      ${myProps.map((p) => `<label style="display:block;"><input type="checkbox" value="${p.idx}" /> ${escapeHtml(p.space.name)}</label>`).join("") || "<em>Καμία</em>"}
    </div>
    <div style="margin-top:8px;font-size:0.8rem;">Ιδιοκτησίες του άλλου (επίλεξε όσες παίρνεις):</div>
    <div id="trade-props-to"></div>
    <button class="btn secondary wide" id="btn-trade" style="margin-top:8px;">Ολοκλήρωση ανταλλαγής</button>
  `;

  const fillOther = () => {
    const oid = Number(area.querySelector("#trade-with").value);
    const op = game.propertiesOf(oid).filter((p) => p.houses === 0);
    area.querySelector("#trade-props-to").innerHTML =
      op.map((p) => `<label style="display:block;"><input type="checkbox" value="${p.idx}" /> ${escapeHtml(p.space.name)}</label>`).join("") || "<em>Καμία</em>";
  };
  fillOther();
  area.querySelector("#trade-with").onchange = fillOther;

  area.querySelector("#btn-trade").onclick = () => {
    const toId = Number(area.querySelector("#trade-with").value);
    const moneyFrom = Number(area.querySelector("#trade-money-from").value) || 0;
    const moneyTo = Number(area.querySelector("#trade-money-to").value) || 0;
    const propsFrom = [...area.querySelectorAll("#trade-props-from input:checked")].map((c) => Number(c.value));
    const propsTo = [...area.querySelectorAll("#trade-props-to input:checked")].map((c) => Number(c.value));
    // Επιβεβαίωση και από τους δύο (hotseat)
    showModal("Επιβεβαίωση ανταλλαγής", `
      <p>${escapeHtml(me.name)} ⇄ ${escapeHtml(game.players[toId].name)}</p>
      <p>Ο/Η <strong>${escapeHtml(game.players[toId].name)}</strong> συμφωνεί;</p>
    `, [
      {
        label: "Ναι, συμφωνώ",
        primary: true,
        onClick: () => {
          const r = game.trade({ fromId: me.id, toId, moneyFrom, moneyTo, propsFrom, propsTo });
          hideModal();
          if (!r.ok) flash(r.err);
          render();
        },
      },
      { label: "Άκυρο", onClick: hideModal },
    ]);
  };
}

const seenToasts = new Set();

function renderLog() {
  const ul = document.getElementById("log");
  const items = [...(game.timeline || game.log)].reverse();
  ul.innerHTML = items.map((e) => `
    <li>
      <button type="button" class="log-link${e.id === game._viewId ? " current" : ""}" data-id="${e.id}">${escapeHtml(e.msg)}</button>
    </li>`).join("");
  ul.querySelectorAll(".log-link").forEach((btn) => {
    btn.onclick = () => {
      if (!game.restore(Number(btn.dataset.id))) return;
      hideModal();
      render();
    };
  });
  const fresh = game.log.filter((e) => !seenToasts.has(e.id));
  fresh.reverse();
  for (const e of fresh) {
    seenToasts.add(e.id);
    showToast(e.msg);
  }
}

function showToast(msg) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  document.getElementById("toasts").appendChild(el);
  setTimeout(() => {
    el.classList.add("out");
    setTimeout(() => el.remove(), 250);
  }, 3000);
}

/* ---------- Modal / helpers ---------- */
function showModal(title, bodyHtml, actions) {
  const modal = document.getElementById("modal");
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-body").innerHTML = bodyHtml;
  const act = document.getElementById("modal-actions");
  act.innerHTML = "";
  for (const a of actions) {
    const b = document.createElement("button");
    b.className = `btn ${a.primary ? "primary" : "secondary"}`;
    b.textContent = a.label;
    b.onclick = a.onClick;
    act.appendChild(b);
  }
  modal.hidden = false;
}

function hideModal() {
  document.getElementById("modal").hidden = true;
}

function flash(msg) {
  showModal("Προσοχή", `<p>${escapeHtml(msg)}</p>`, [{ label: "OK", primary: true, onClick: hideModal }]);
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/* ---------- Events ---------- */
document.getElementById("btn-roll").onclick = async () => {
  if (!game || game.phase !== "roll" || game.animating) return;
  const result = await game.rollDice();
  if (result && game.lastCard) {
    const card = game.lastCard;
    game.lastCard = null;
    showModal(card.label, `<div class="card-reveal">${escapeHtml(card.text)}</div>`, [
      { label: "OK", primary: true, onClick: () => { hideModal(); render(); } },
    ]);
  }
  render();
};

document.getElementById("btn-new-game").onclick = () => {
  if (confirm("Να ξεκινήσει νέο παιχνίδι;")) location.reload();
};

initSetup();
