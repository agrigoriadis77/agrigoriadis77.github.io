/** Μηχανή παιχνιδιού — hotseat, χωρίς μποτ. */

class MonopolyGame {
  constructor(playerDefs) {
    this.players = playerDefs.map((p, i) => ({
      id: i,
      name: p.name,
      token: p.token,
      money: START_MONEY,
      position: 0,
      inJail: false,
      jailTurns: 0,
      jailFreeCards: 0,
      bankrupt: false,
      doublesCount: 0,
    }));

    this.ownership = {}; // spaceIndex -> { ownerId, houses: 0..5 (5=hotel), mortgaged: bool }
    this.housesLeft = HOUSE_LIMIT;
    this.hotelsLeft = HOTEL_LIMIT;
    this.current = 0;
    this.phase = "roll"; // roll | post-roll | buy | auction | must-pay | end | gameover
    this.dice = [0, 0];
    this.lastDoubles = false;
    this.pendingRent = null;
    this.pendingBuy = null;
    this.auction = null;
    this.freeParkingPot = 0;
    this.chanceDeck = shuffle(CHANCE_CARDS);
    this.chestDeck = shuffle(CHEST_CARDS);
    this.log = [];
    this.winner = null;
    this.doublesRentPending = false;
    this.animating = false;
    this.timeline = [];
    this._epoch = 0;
    this._viewId = null;
    this._addLog(`Ξεκινά το παιχνίδι με ${this.players.length} παίκτες. Καθένας έχει ${formatMoney(START_MONEY)}.`);
  }

  get currentPlayer() {
    return this.players[this.current];
  }

  alivePlayers() {
    return this.players.filter((p) => !p.bankrupt);
  }

  _addLog(msg) {
    if (this._viewId != null && this.timeline) {
      const idx = this.timeline.findIndex((e) => e.id === this._viewId);
      if (idx !== -1 && idx < this.timeline.length - 1) this.timeline = this.timeline.slice(0, idx + 1);
    }
    const id = (this._logSeq = (this._logSeq || 0) + 1);
    this.log.unshift({ t: Date.now(), msg, id });
    if (this.log.length > 80) this.log.pop();
    this.timeline.push({ id, msg, state: null });
    if (this.timeline.length > 80) this.timeline.shift();
    this._viewId = id;
    const epoch = this._epoch;
    queueMicrotask(() => {
      if (this._epoch !== epoch) return;
      this._fillSnapshot(id);
    });
  }

  _capture() {
    return structuredClone({
      players: this.players,
      ownership: this.ownership,
      housesLeft: this.housesLeft,
      hotelsLeft: this.hotelsLeft,
      current: this.current,
      phase: this.phase,
      dice: this.dice,
      lastDoubles: this.lastDoubles,
      pendingRent: this.pendingRent,
      pendingBuy: this.pendingBuy,
      auction: this.auction,
      freeParkingPot: this.freeParkingPot,
      chanceDeck: this.chanceDeck,
      chestDeck: this.chestDeck,
      doublesRentPending: this.doublesRentPending,
      winner: this.winner,
      log: this.log,
      _logSeq: this._logSeq,
    });
  }

  _fillSnapshot(id) {
    const entry = this.timeline.find((e) => e.id === id);
    if (!entry || this._epoch == null) return;
    entry.state = this._capture();
  }

  restore(id) {
    const entry = this.timeline.find((e) => e.id === id);
    if (!entry || !entry.state) return false;
    this._epoch += 1;
    const timeline = this.timeline;
    const onRoll = this.onRoll;
    const onStep = this.onStep;
    const onCard = this.onCard;
    const resume = this._resumeCard;
    this._resumeCard = null;
    Object.assign(this, structuredClone(entry.state));
    this.timeline = timeline;
    this.onRoll = onRoll;
    this.onStep = onStep;
    this.onCard = onCard;
    this._viewId = id;
    this.animating = false;
    this.lastCard = null;
    if (resume) resume();
    return true;
  }

  _nextAlive(from) {
    let i = from;
    do {
      i = (i + 1) % this.players.length;
    } while (this.players[i].bankrupt && i !== from);
    return i;
  }

  endTurn() {
    if (this.phase === "gameover") return;
    const p = this.currentPlayer;
    if (!this.lastDoubles || p.inJail || p.bankrupt) {
      p.doublesCount = 0;
      this.current = this._nextAlive(this.current);
    }
    this.lastDoubles = false;
    this.phase = "roll";
    this.pendingBuy = null;
    this.pendingRent = null;
    this.doublesRentPending = false;
    this._checkWinner();
  }

  _checkWinner() {
    const alive = this.alivePlayers();
    if (alive.length === 1) {
      this.winner = alive[0];
      this.phase = "gameover";
      this._addLog(`Νικητής: ${this.winner.name}!`);
    }
  }

  async rollDice() {
    if (this.phase !== "roll" || this.winner || this.animating) return null;
    const p = this.currentPlayer;
    const d1 = 1 + Math.floor(Math.random() * 6);
    const d2 = 1 + Math.floor(Math.random() * 6);
    this.dice = [d1, d2];
    const doubles = d1 === d2;
    this.lastDoubles = doubles;
    this.animating = true;
    if (this.onRoll) this.onRoll();

    try {
      if (p.inJail) {
        return await this._rollFromJail(d1, d2, doubles);
      }

      if (doubles) {
        p.doublesCount += 1;
        if (p.doublesCount === 3) {
          this._addLog(`${p.name} έφερε 3 φορές διπλές — πάει στη Φυλακή!`);
          this._sendToJail(p);
          this.lastDoubles = false;
          p.doublesCount = 0;
          this.phase = "end";
          return { d1, d2, doubles, wentToJail: true };
        }
      } else {
        p.doublesCount = 0;
      }

      await this._movePlayer(p, d1 + d2);
      return { d1, d2, doubles };
    } finally {
      this.animating = false;
    }
  }

  async _rollFromJail(d1, d2, doubles) {
    const p = this.currentPlayer;
    if (doubles) {
      p.inJail = false;
      p.jailTurns = 0;
      this.lastDoubles = false; // μετά από έξοδο με διπλές δεν ξαναρίχνει
      this._addLog(`${p.name} έφερε διπλές και βγαίνει από τη Φυλακή.`);
      await this._movePlayer(p, d1 + d2);
      return { d1, d2, doubles, leftJail: true };
    }
    p.jailTurns += 1;
    if (p.jailTurns >= 3) {
      if (p.money < JAIL_FINE && !this._canRaise(p, JAIL_FINE)) {
        this.phase = "must-pay";
        this.pendingRent = { amount: JAIL_FINE, to: null, reason: "πρόστιμο φυλακής" };
        this._addLog(`${p.name} πρέπει να πληρώσει ${formatMoney(JAIL_FINE)} για να βγει.`);
        return { d1, d2, doubles, mustPayJail: true };
      }
      this._payBank(p, JAIL_FINE);
      p.inJail = false;
      p.jailTurns = 0;
      this._addLog(`${p.name} πλήρωσε ${formatMoney(JAIL_FINE)} και βγαίνει από τη Φυλακή.`);
      await this._movePlayer(p, d1 + d2);
      return { d1, d2, doubles, paidJail: true };
    }
    this._addLog(`${p.name} δεν έφερε διπλές (παραμένει στη Φυλακή, γύρος ${p.jailTurns}/3).`);
    this.phase = "end";
    this.lastDoubles = false;
    return { d1, d2, doubles, stayedInJail: true };
  }

  payJailFine() {
    const p = this.currentPlayer;
    if (!p.inJail || this.phase !== "roll") return false;
    if (!this._tryPay(p, JAIL_FINE, null, "έξοδος από τη Φυλακή")) return false;
    p.inJail = false;
    p.jailTurns = 0;
    this._addLog(`${p.name} πλήρωσε ${formatMoney(JAIL_FINE)} και βγαίνει από τη Φυλακή.`);
    return true;
  }

  useJailFreeCard() {
    const p = this.currentPlayer;
    if (!p.inJail || p.jailFreeCards < 1 || this.phase !== "roll") return false;
    p.jailFreeCards -= 1;
    p.inJail = false;
    p.jailTurns = 0;
    this._addLog(`${p.name} χρησιμοποίησε κάρτα «Βγείτε δωρεάν από τη Φυλακή».`);
    return true;
  }

  async _follow(p, path, collectGo) {
    const epoch = this._epoch;
    for (const pos of path) {
      if (this._epoch !== epoch) return false;
      p.position = pos;
      if (collectGo && pos === 0) {
        p.money += GO_SALARY;
        this._addLog(`${p.name} πέρασε από την Αφετηρία και πήρε ${formatMoney(GO_SALARY)}.`);
      }
      if (this.onStep) await this.onStep(p);
      if (this._epoch !== epoch) return false;
    }
    return true;
  }

  _pathSteps(from, steps, dir) {
    const path = [];
    let pos = from;
    for (let i = 0; i < steps; i++) {
      pos = (pos + dir + 40) % 40;
      path.push(pos);
    }
    return path;
  }

  _pathUntil(from, target) {
    const path = [];
    let pos = from;
    if (pos === target) return path;
    do {
      pos = (pos + 1) % 40;
      path.push(pos);
    } while (pos !== target);
    return path;
  }

  async _movePlayer(p, steps) {
    const epoch = this._epoch;
    const ok = await this._follow(p, this._pathSteps(p.position, steps, 1), true);
    if (!ok || this._epoch !== epoch) return;
    this._addLog(`${p.name} μετακινήθηκε στη θέση: ${BOARD[p.position].name}.`);
    const id = this.log[0].id;
    await this._resolveSpace(p);
    if (this._epoch !== epoch) return;
    this._fillSnapshot(id);
  }

  async _moveTo(p, target, collectGo) {
    const epoch = this._epoch;
    const ok = await this._follow(p, this._pathUntil(p.position, target), !!collectGo);
    if (!ok || this._epoch !== epoch) return;
    this._addLog(`${p.name} πήγε στο: ${BOARD[p.position].name}.`);
    const id = this.log[0].id;
    await this._resolveSpace(p);
    if (this._epoch !== epoch) return;
    this._fillSnapshot(id);
  }

  _sendToJail(p) {
    p.position = 10;
    p.inJail = true;
    p.jailTurns = 0;
    p.doublesCount = 0;
    this.lastDoubles = false;
  }

  async _resolveSpace(p) {
    const space = BOARD[p.position];
    switch (space.type) {
      case "go":
      case "jail":
      case "parking":
        this.phase = this.lastDoubles ? "roll" : "end";
        if (space.type === "parking" && this.freeParkingPot > 0) {
          // Κλασικοί κανόνες: η ελεύθερη στάθμευση δεν δίνει λεφτά. Κρατάμε pot=0.
        }
        break;
      case "gotojail":
        this._addLog(`${p.name} πηγαίνει στη Φυλακή!`);
        this._sendToJail(p);
        this.phase = "end";
        break;
      case "tax":
        this._requirePayment(p, space.amount, null, space.name);
        break;
      case "chance":
        await this._drawCard(p, "chance");
        break;
      case "chest":
        await this._drawCard(p, "chest");
        break;
      case "property":
      case "station":
      case "utility":
        this._landOnOwnable(p, p.position);
        break;
      default:
        this.phase = this.lastDoubles ? "roll" : "end";
    }
  }

  _landOnOwnable(p, idx) {
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own) {
      this.pendingBuy = idx;
      this.phase = "buy";
      return;
    }
    if (own.ownerId === p.id || own.mortgaged) {
      this.phase = this.lastDoubles ? "roll" : "end";
      return;
    }
    const rent = this.calculateRent(idx, this.dice[0] + this.dice[1], this.doublesRentPending);
    this.doublesRentPending = false;
    const owner = this.players[own.ownerId];
    this._addLog(`${p.name} οφείλει ενοίκιο ${formatMoney(rent)} στον/στην ${owner.name}.`);
    this._requirePayment(p, rent, owner.id, `ενοίκιο για ${space.name}`);
  }

  calculateRent(idx, diceTotal, doubleStation) {
    const space = BOARD[idx];
    const own = this.ownership[idx];
    if (!own || own.mortgaged) return 0;
    const ownerId = own.ownerId;

    if (space.type === "station") {
      const count = [5, 15, 25, 35].filter((i) => this.ownership[i]?.ownerId === ownerId).length;
      let rent = space.rents[count - 1] || 0;
      if (doubleStation) rent *= 2;
      return rent;
    }
    if (space.type === "utility") {
      const count = [12, 28].filter((i) => this.ownership[i]?.ownerId === ownerId).length;
      const mult = count === 2 ? 10 : 4;
      return diceTotal * mult * 100; // ζάρι × 4/10, σε δρχ. (×100)
    }
    // property
    if (own.houses === 0) {
      let rent = space.rent[0];
      if (this.ownsFullGroup(ownerId, space.color) && this.groupHasNoHouses(space.color)) {
        rent *= 2;
      }
      return rent;
    }
    return space.rent[own.houses];
  }

  ownsFullGroup(playerId, color) {
    return COLOR_GROUPS[color].every((i) => this.ownership[i]?.ownerId === playerId && !this.ownership[i].mortgaged);
  }

  groupHasNoHouses(color) {
    return COLOR_GROUPS[color].every((i) => (this.ownership[i]?.houses || 0) === 0);
  }

  buyProperty() {
    if (this.phase !== "buy" || this.pendingBuy == null) return false;
    const idx = this.pendingBuy;
    const space = BOARD[idx];
    const p = this.currentPlayer;
    if (p.money < space.price) {
      this._addLog(`${p.name} δεν έχει αρκετά χρήματα για αγορά.`);
      return false;
    }
    p.money -= space.price;
    this.ownership[idx] = { ownerId: p.id, houses: 0, mortgaged: false };
    this._addLog(`${p.name} αγόρασε το/την ${space.name} για ${formatMoney(space.price)}.`);
    this.pendingBuy = null;
    this.phase = this.lastDoubles ? "roll" : "end";
    return true;
  }

  declineBuy() {
    if (this.phase !== "buy" || this.pendingBuy == null) return false;
    const idx = this.pendingBuy;
    this.pendingBuy = null;
    this._startAuction(idx);
    return true;
  }

  _startAuction(idx) {
    const bidders = this.alivePlayers().map((p) => p.id);
    this.auction = {
      idx,
      bidders,
      currentBid: 0,
      highBidder: null,
      turn: 0,
      passed: new Set(),
    };
    this.phase = "auction";
    this._addLog(`Δημοπρασία για: ${BOARD[idx].name}. Ξεκινά από 0 δρχ.`);
  }

  auctionBid(amount) {
    if (this.phase !== "auction" || !this.auction) return false;
    const a = this.auction;
    const pid = a.bidders[a.turn];
    const p = this.players[pid];
    amount = Math.floor(Number(amount));
    if (!Number.isFinite(amount) || amount <= a.currentBid) return false;
    if (p.money < amount) return false;
    a.currentBid = amount;
    a.highBidder = pid;
    a.passed.clear();
    this._addLog(`${p.name} πλειοδοτεί ${formatMoney(amount)}.`);
    this._auctionAdvance();
    return true;
  }

  auctionPass() {
    if (this.phase !== "auction" || !this.auction) return false;
    const a = this.auction;
    const pid = a.bidders[a.turn];
    a.passed.add(pid);
    this._addLog(`${this.players[pid].name} πάσο.`);
    if (a.highBidder == null && a.passed.size >= a.bidders.length) {
      this._endAuction(false);
      return true;
    }
    if (a.highBidder != null && a.bidders.every((id) => id === a.highBidder || a.passed.has(id))) {
      this._endAuction(true);
      return true;
    }
    this._auctionAdvance();
    return true;
  }

  _auctionAdvance() {
    const a = this.auction;
    if (!a) return;
    for (let i = 0; i < a.bidders.length; i++) {
      a.turn = (a.turn + 1) % a.bidders.length;
      const pid = a.bidders[a.turn];
      if (!a.passed.has(pid)) return;
    }
    if (a.highBidder != null) this._endAuction(true);
    else this._endAuction(false);
  }

  _endAuction(sold) {
    const a = this.auction;
    const space = BOARD[a.idx];
    if (sold && a.highBidder != null && a.currentBid > 0) {
      const p = this.players[a.highBidder];
      p.money -= a.currentBid;
      this.ownership[a.idx] = { ownerId: p.id, houses: 0, mortgaged: false };
      this._addLog(`${p.name} κέρδισε τη δημοπρασία του/της ${space.name} με ${formatMoney(a.currentBid)}.`);
    } else {
      this._addLog(`Κανείς δεν αγόρασε το/την ${space.name}.`);
    }
    this.auction = null;
    this.phase = this.lastDoubles ? "roll" : "end";
  }

  _requirePayment(p, amount, toId, reason) {
    if (amount <= 0) {
      this.phase = this.lastDoubles ? "roll" : "end";
      return;
    }
    if (p.money >= amount) {
      this._pay(p, amount, toId, reason);
      this.phase = this.lastDoubles && !p.inJail ? "roll" : "end";
      return;
    }
    if (this._netWorth(p) < amount) {
      this._bankrupt(p, toId);
      return;
    }
    this.pendingRent = { amount, to: toId, reason };
    this.phase = "must-pay";
    this._addLog(`${p.name} πρέπει να μαζέψει ${formatMoney(amount)} (${reason}). Υποθήκευσε ή πούλησε κτίρια.`);
  }

  trySettleDebt() {
    if (this.phase !== "must-pay" || !this.pendingRent) return false;
    const p = this.currentPlayer;
    const { amount, to, reason } = this.pendingRent;
    if (p.money >= amount) {
      this._pay(p, amount, to, reason);
      this.pendingRent = null;
      this.phase = this.lastDoubles && !p.inJail ? "roll" : "end";
      return true;
    }
    if (this._netWorth(p) < amount) {
      this._bankrupt(p, to);
      return true;
    }
    return false;
  }

  _pay(from, amount, toId, reason) {
    from.money -= amount;
    if (toId == null) {
      this._addLog(`${from.name} πλήρωσε ${formatMoney(amount)} στην τράπεζα (${reason}).`);
    } else {
      this.players[toId].money += amount;
      this._addLog(`${from.name} πλήρωσε ${formatMoney(amount)} στον/στην ${this.players[toId].name} (${reason}).`);
    }
  }

  _payBank(p, amount) {
    p.money -= amount;
  }

  _tryPay(p, amount, toId, reason) {
    if (p.money < amount) {
      if (this._netWorth(p) < amount) {
        this._bankrupt(p, toId);
        return false;
      }
      this.pendingRent = { amount, to: toId, reason };
      this.phase = "must-pay";
      return false;
    }
    this._pay(p, amount, toId, reason);
    return true;
  }

  _canRaise(p, amount) {
    return this._netWorth(p) >= amount;
  }

  _netWorth(p) {
    let w = p.money;
    for (const [idx, own] of Object.entries(this.ownership)) {
      if (own.ownerId !== p.id) continue;
      const space = BOARD[idx];
      if (own.houses === 5) {
        w += space.houseCost * 5 * 0.5;
      } else if (own.houses > 0) {
        w += space.houseCost * own.houses * 0.5;
      }
      if (!own.mortgaged) w += space.mortgage;
    }
    return w;
  }

  _bankrupt(p, creditorId) {
    this._addLog(`${p.name} χρεοκόπησε!`);
    // Επιστροφή κτιρίων στην τράπεζα
    for (const [idx, own] of Object.entries(this.ownership)) {
      if (own.ownerId !== p.id) continue;
      const space = BOARD[idx];
      if (space.type === "property") {
        if (own.houses === 5) {
          this.hotelsLeft += 1;
          this.housesLeft += 4;
        } else {
          this.housesLeft += own.houses;
        }
      }
      if (creditorId == null) {
        delete this.ownership[idx];
      } else {
        this.ownership[idx] = {
          ownerId: creditorId,
          houses: 0,
          mortgaged: own.mortgaged,
        };
      }
    }
    if (creditorId != null) {
      this.players[creditorId].money += p.money;
      this.players[creditorId].jailFreeCards += p.jailFreeCards;
    }
    p.money = 0;
    p.jailFreeCards = 0;
    p.bankrupt = true;
    this.pendingRent = null;
    this.pendingBuy = null;
    this.auction = null;
    this.lastDoubles = false;
    this.phase = "end";
    this._checkWinner();
  }

  canBuildHouse(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id || space.type !== "property") return false;
    if (own.mortgaged || own.houses >= 5) return false;
    if (!this.ownsFullGroup(p.id, space.color)) return false;
    const group = COLOR_GROUPS[space.color];
    const minH = Math.min(...group.map((i) => this.ownership[i].houses));
    if (own.houses > minH) return false;
    if (p.money < space.houseCost) return false;
    if (own.houses === 4) return this.hotelsLeft >= 1;
    return this.housesLeft >= 1;
  }

  canSellHouse(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id || space.type !== "property") return false;
    if (own.houses <= 0) return false;
    const group = COLOR_GROUPS[space.color];
    const maxH = Math.max(...group.map((i) => this.ownership[i].houses));
    if (own.houses < maxH) return false;
    if (own.houses === 5 && this.housesLeft < 4) return false;
    return true;
  }

  buildHouse(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id || space.type !== "property") return { ok: false, err: "Δεν σας ανήκει." };
    if (own.mortgaged) return { ok: false, err: "Είναι υποθηκευμένο." };
    if (!this.ownsFullGroup(p.id, space.color)) return { ok: false, err: "Χρειάζεστε όλη την ομάδα χρώματος." };
    if (own.houses >= 5) return { ok: false, err: "Έχει ήδη ξενοδοχείο." };
    // Ομοιόμορφη δόμηση
    const group = COLOR_GROUPS[space.color];
    const minH = Math.min(...group.map((i) => this.ownership[i].houses));
    if (own.houses > minH) return { ok: false, err: "Πρέπει να χτίζετε ομοιόμορφα." };
    if (own.houses === 4) {
      if (this.hotelsLeft < 1) return { ok: false, err: "Δεν υπάρχουν ξενοδοχεία." };
      if (p.money < space.houseCost) return { ok: false, err: "Όχι αρκετά χρήματα." };
      p.money -= space.houseCost;
      own.houses = 5;
      this.housesLeft += 4;
      this.hotelsLeft -= 1;
      this._addLog(`${p.name} έχτισε ξενοδοχείο στην ${space.name}.`);
      return { ok: true };
    }
    if (this.housesLeft < 1) return { ok: false, err: "Δεν υπάρχουν σπίτια." };
    if (p.money < space.houseCost) return { ok: false, err: "Όχι αρκετά χρήματα." };
    p.money -= space.houseCost;
    own.houses += 1;
    this.housesLeft -= 1;
    this._addLog(`${p.name} έχτισε σπίτι στην ${space.name}.`);
    return { ok: true };
  }

  sellHouse(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id || space.type !== "property") return { ok: false, err: "Δεν σας ανήκει." };
    if (own.houses <= 0) return { ok: false, err: "Δεν έχει κτίρια." };
    const group = COLOR_GROUPS[space.color];
    const maxH = Math.max(...group.map((i) => this.ownership[i].houses));
    if (own.houses < maxH) return { ok: false, err: "Πουλήστε ομοιόμορφα." };
    if (own.houses === 5) {
      if (this.housesLeft < 4) return { ok: false, err: "Δεν υπάρχουν 4 σπίτια για αντικατάσταση." };
      own.houses = 4;
      this.hotelsLeft += 1;
      this.housesLeft -= 4;
      p.money += space.houseCost / 2;
      this._addLog(`${p.name} πούλησε ξενοδοχείο από την ${space.name}.`);
      return { ok: true };
    }
    own.houses -= 1;
    this.housesLeft += 1;
    p.money += space.houseCost / 2;
    this._addLog(`${p.name} πούλησε σπίτι από την ${space.name}.`);
    return { ok: true };
  }

  mortgage(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id) return { ok: false, err: "Δεν σας ανήκει." };
    if (own.mortgaged) return { ok: false, err: "Ήδη υποθηκευμένο." };
    if (space.type === "property" && own.houses > 0) return { ok: false, err: "Πουλήστε πρώτα τα κτίρια." };
    if (space.type === "property") {
      const group = COLOR_GROUPS[space.color];
      if (group.some((i) => (this.ownership[i]?.houses || 0) > 0)) {
        return { ok: false, err: "Πουλήστε όλα τα κτίρια της ομάδας." };
      }
    }
    own.mortgaged = true;
    p.money += space.mortgage;
    this._addLog(`${p.name} υποθήκευσε το/την ${space.name} (+${formatMoney(space.mortgage)}).`);
    if (this.phase === "must-pay") this.trySettleDebt();
    return { ok: true };
  }

  unmortgage(idx) {
    const p = this.currentPlayer;
    const own = this.ownership[idx];
    const space = BOARD[idx];
    if (!own || own.ownerId !== p.id) return { ok: false, err: "Δεν σας ανήκει." };
    if (!own.mortgaged) return { ok: false, err: "Δεν είναι υποθηκευμένο." };
    const cost = Math.floor(space.mortgage * 1.1);
    if (p.money < cost) return { ok: false, err: "Όχι αρκετά χρήματα." };
    p.money -= cost;
    own.mortgaged = false;
    this._addLog(`${p.name} εξόφλησε την υποθήκη του/της ${space.name} (−${formatMoney(cost)}).`);
    return { ok: true };
  }

  trade({ fromId, toId, moneyFrom, moneyTo, propsFrom, propsTo }) {
    const a = this.players[fromId];
    const b = this.players[toId];
    if (!a || !b || a.bankrupt || b.bankrupt) return { ok: false, err: "Μη έγκυροι παίκτες." };
    moneyFrom = Math.max(0, Math.floor(moneyFrom || 0));
    moneyTo = Math.max(0, Math.floor(moneyTo || 0));
    propsFrom = propsFrom || [];
    propsTo = propsTo || [];

    if (a.money < moneyFrom || b.money < moneyTo) return { ok: false, err: "Όχι αρκετά χρήματα." };

    for (const idx of propsFrom) {
      const own = this.ownership[idx];
      if (!own || own.ownerId !== fromId) return { ok: false, err: "Λάθος ιδιοκτησία." };
      if (own.houses > 0) return { ok: false, err: "Πουλήστε κτίρια πριν την ανταλλαγή." };
    }
    for (const idx of propsTo) {
      const own = this.ownership[idx];
      if (!own || own.ownerId !== toId) return { ok: false, err: "Λάθος ιδιοκτησία." };
      if (own.houses > 0) return { ok: false, err: "Πουλήστε κτίρια πριν την ανταλλαγή." };
    }

    a.money -= moneyFrom;
    b.money += moneyFrom;
    b.money -= moneyTo;
    a.money += moneyTo;
    for (const idx of propsFrom) this.ownership[idx].ownerId = toId;
    for (const idx of propsTo) this.ownership[idx].ownerId = fromId;

    this._addLog(`Ανταλλαγή μεταξύ ${a.name} και ${b.name}.`);
    if (this.phase === "must-pay") this.trySettleDebt();
    return { ok: true };
  }

  async _drawCard(p, kind) {
    const deck = kind === "chance" ? this.chanceDeck : this.chestDeck;
    const label = kind === "chance" ? "Απόφαση" : "Εντολή";
    if (deck.length === 0) {
      if (kind === "chance") this.chanceDeck = shuffle(CHANCE_CARDS);
      else this.chestDeck = shuffle(CHEST_CARDS);
    }
    const card = (kind === "chance" ? this.chanceDeck : this.chestDeck).pop();
    this.lastCard = { label, text: card.text };
    this._addLog(`${p.name} τράβηξε κάρτα ${label}: «${card.text}»`);
    const id = this.log[0].id;
    const epoch = this._epoch;
    if (this.onCard) await this.onCard(this.lastCard);
    if (this._epoch !== epoch) return;
    await this._applyCard(p, card);
    if (this._epoch !== epoch) return;
    this._fillSnapshot(id);
  }

  async _applyCard(p, card) {
    if (card.jailFree) {
      p.jailFreeCards += 1;
      this.phase = this.lastDoubles ? "roll" : "end";
      return;
    }
    if (card.goToJail) {
      this._sendToJail(p);
      this.phase = "end";
      return;
    }
    if (card.money) {
      if (card.money > 0) {
        p.money += card.money;
        this.phase = this.lastDoubles ? "roll" : "end";
      } else {
        this._requirePayment(p, -card.money, null, "κάρτα");
      }
      return;
    }
    if (card.payEach) {
      const others = this.alivePlayers().filter((o) => o.id !== p.id);
      const total = card.payEach * others.length;
      if (p.money >= total) {
        for (const o of others) {
          p.money -= card.payEach;
          o.money += card.payEach;
        }
        this._addLog(`${p.name} πλήρωσε ${formatMoney(card.payEach)} σε κάθε παίκτη.`);
        this.phase = this.lastDoubles ? "roll" : "end";
      } else {
        this._requirePayment(p, total, null, "πληρωμή σε όλους");
        // Όταν ξοφλήσει, μοιράζουμε — απλοποίηση: πάει στην τράπεζα αν χρεοκοπήσει
      }
      return;
    }
    if (card.collectEach) {
      for (const o of this.alivePlayers()) {
        if (o.id === p.id) continue;
        if (o.money >= card.collectEach) {
          o.money -= card.collectEach;
          p.money += card.collectEach;
        } else {
          // Παίρνει ό,τι έχει
          p.money += o.money;
          o.money = 0;
        }
      }
      this._addLog(`${p.name} πήρε ${formatMoney(card.collectEach)} από κάθε παίκτη.`);
      this.phase = this.lastDoubles ? "roll" : "end";
      return;
    }
    if (card.repairs) {
      let cost = 0;
      for (const [idx, own] of Object.entries(this.ownership)) {
        if (own.ownerId !== p.id) continue;
        if (BOARD[idx].type !== "property") continue;
        if (own.houses === 5) cost += card.repairs.hotel;
        else cost += own.houses * card.repairs.house;
      }
      this._requirePayment(p, cost, null, "επισκευές");
      return;
    }
    if (card.moveBack) {
      const epoch = this._epoch;
      const ok = await this._follow(p, this._pathSteps(p.position, card.moveBack, -1), false);
      if (!ok || this._epoch !== epoch) return;
      this._addLog(`${p.name} πήγε πίσω στη θέση: ${BOARD[p.position].name}.`);
      const id = this.log[0].id;
      await this._resolveSpace(p);
      if (this._epoch !== epoch) return;
      this._fillSnapshot(id);
      return;
    }
    if (card.moveTo != null) {
      await this._moveTo(p, card.moveTo, card.collectGo);
      return;
    }
    if (card.nearestUtility) {
      const epoch = this._epoch;
      const utils = [12, 28];
      const pos = p.position;
      let dest = utils.find((u) => u > pos);
      if (dest == null) dest = utils[0];
      const ok = await this._follow(p, this._pathUntil(pos, dest), true);
      if (!ok || this._epoch !== epoch) return;
      this._addLog(`${p.name} πήγε στο: ${BOARD[p.position].name}.`);
      const own = this.ownership[dest];
      if (!own) {
        this.pendingBuy = dest;
        this.phase = "buy";
      } else if (own.ownerId !== p.id && !own.mortgaged) {
        const roll = (1 + Math.floor(Math.random() * 6)) + (1 + Math.floor(Math.random() * 6));
        this.dice = [Math.floor(roll / 2), roll - Math.floor(roll / 2)];
        const rent = roll * 10 * 100;
        this._addLog(`Ζάρι για εταιρία: ${roll}. Ενοίκιο ${formatMoney(rent)}.`);
        this._requirePayment(p, rent, own.ownerId, BOARD[dest].name);
      } else {
        this.phase = this.lastDoubles ? "roll" : "end";
      }
      return;
    }
    if (card.nearestStation) {
      const stations = [5, 15, 25, 35];
      const pos = p.position;
      let dest = stations.find((s) => s > pos);
      if (dest == null) dest = stations[0];
      this.doublesRentPending = !!card.doubleRent;
      await this._moveTo(p, dest, true);
      return;
    }
    this.phase = this.lastDoubles ? "roll" : "end";
  }

  propertiesOf(playerId) {
    return Object.entries(this.ownership)
      .filter(([, o]) => o.ownerId === playerId)
      .map(([idx, o]) => ({ idx: Number(idx), ...o, space: BOARD[idx] }));
  }
}
